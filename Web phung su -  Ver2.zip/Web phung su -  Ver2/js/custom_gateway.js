function delay(){
	setTimeout(load_index, 2000)
}	

function load_index() {
    window.location.href = "gateway-menu.html";
}