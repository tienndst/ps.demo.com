<div class="ads">
	ads1
</div>
<div class="ads">
	ads2
</div>